<?php
declare(strict_types=1);

header('Content-Type: text/plain; charset=utf-8');

require_once __DIR__ . '/../lib/ia.php';
require_once __DIR__ . '/../lib/itunes.php';

$decade = (int)($_GET['decade'] ?? 1990);
$stylesParam = trim((string)($_GET['styles'] ?? 'pop,rock,house'));
$limit = (int)($_GET['limit'] ?? 200);

if ($decade < 1900 || $decade > 2020 || ($decade % 10) !== 0) { echo "decade invalide\n"; exit; }
$limit = max(50, min(2000, $limit));

$styles = array_values(array_filter(array_map('trim', explode(',', $stylesParam))));
$styles = array_values(array_unique($styles));
if (!$styles) { echo "styles vides\n"; exit; }

$yearStart = $decade;
$yearEnd = $decade + 9;

$cacheDir = __DIR__ . '/../data/cache';
ia_ensure_dir($cacheDir);

$libPath = __DIR__ . '/../data/library.json';
$existing = [];
if (is_file($libPath)) {
  $existing = json_decode((string)file_get_contents($libPath), true);
  if (!is_array($existing)) $existing = [];
}

// Anti-duplication
$seen = [];
foreach ($existing as $t) {
  if (!empty($t['audio_url'])) $seen[$t['audio_url']] = true;
}

$added = 0;

foreach ($styles as $st) {
  if ($added >= $limit) break;

  echo "== Style: $st | Decade: {$decade}s ==\n";

  // Petits pools : on “accumule” sur plusieurs warmups si besoin
  $pool = array_merge(
    ia_get_pool($st, $yearStart, $yearEnd, $cacheDir, 120),
    itunes_get_pool($st, $yearStart, $yearEnd, 120)
  );

  foreach ($pool as $t) {
    if ($added >= $limit) break;
    $u = (string)($t['audio_url'] ?? '');
    if ($u === '' || isset($seen[$u])) continue;

    $t['style'] = $st; // tag du style d’origine (pour filtrage rapide)
    $existing[] = $t;
    $seen[$u] = true;
    $added++;

    echo " + {$t['title']} ({$t['duration_sec']}s)\n";
  }

  echo "\n";
}

file_put_contents($libPath, json_encode($existing, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT));
echo "Done. Added: $added\nSaved: data/library.json\n";
