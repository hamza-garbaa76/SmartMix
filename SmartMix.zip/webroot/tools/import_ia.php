<?php
declare(strict_types=1);

/**
 * Simple importer from Internet Archive into data/tracks.json
 * Use carefully (free API, may be slow).
 */

header('Content-Type: text/plain; charset=utf-8');

$genre = strtolower(trim((string)($_GET['genre'] ?? 'rock')));
$mood  = strtolower(trim((string)($_GET['mood'] ?? 'workout')));
$decade = (int)($_GET['decade'] ?? 1990);
$limit = (int)($_GET['limit'] ?? 40);

if ($decade < 1900 || $decade > 2020 || ($decade % 10) !== 0) {
  echo "decade invalide\n"; exit;
}
$limit = max(5, min(200, $limit));
$yStart = $decade;
$yEnd = $decade + 9;

function http_json(string $url, int $timeout = 25): ?array {
  $ctx = stream_context_create([
    'http' => [
      'method' => 'GET',
      'timeout' => $timeout,
      'header' => "User-Agent: SmartMixImporter/1.0\r\nAccept: application/json\r\n",
    ]
  ]);
  $raw = @file_get_contents($url, false, $ctx);
  if ($raw === false) return null;
  $j = json_decode($raw, true);
  return is_array($j) ? $j : null;
}

function parse_len(?string $s): int {
  if (!$s) return 0;
  $s = trim($s);
  if (preg_match('~^(\d{1,2}):(\d{2})(?::(\d{2}))?$~', $s, $m)) {
    if (!empty($m[3])) return ((int)$m[1])*3600 + ((int)$m[2])*60 + (int)$m[3];
    return ((int)$m[1])*60 + (int)$m[2];
  }
  if (ctype_digit($s)) return (int)$s;
  return 0;
}

$dataPath = __DIR__ . '/../data/tracks.json';
$existing = [];
if (is_file($dataPath)) {
  $existing = json_decode((string)file_get_contents($dataPath), true);
  if (!is_array($existing)) $existing = [];
}

// avoid duplicates by audio_url
$seen = [];
foreach ($existing as $t) {
  if (!empty($t['audio_url'])) $seen[$t['audio_url']] = true;
}

$q = sprintf(
  '(mediatype:audio AND year:[%d TO %d] AND (subject:"%s" OR title:"%s" OR description:"%s"))',
  $yStart, $yEnd, $genre, $genre, $genre
);
$fields = rawurlencode('identifier,title,creator,year,subject');
$url = 'https://archive.org/services/search/v1/scrape'
  . '?fields=' . $fields
  . '&q=' . rawurlencode($q)
  . '&count=200';

echo "Query: $q\n\n";
$search = http_json($url);
$items = $search['items'] ?? [];
if (!is_array($items) || !$items) {
  echo "No items found.\n"; exit;
}

$added = 0;
foreach ($items as $it) {
  if ($added >= $limit) break;
  $id = $it['identifier'] ?? null;
  if (!$id) continue;

  $meta = http_json('https://archive.org/metadata/' . rawurlencode((string)$id));
  if (!$meta || empty($meta['files']) || !is_array($meta['files'])) continue;

  $creator = $meta['metadata']['creator'] ?? ($it['creator'] ?? null);
  if (is_array($creator)) $creator = implode(', ', $creator);
  $year = $meta['metadata']['year'] ?? ($it['year'] ?? null);
  $yearInt = null;
  if (is_string($year) && preg_match('~(\d{4})~', $year, $m)) $yearInt = (int)$m[1];
  if (is_int($year)) $yearInt = $year;
  if ($yearInt === null || $yearInt < $yStart || $yearInt > $yEnd) continue;

  foreach ($meta['files'] as $f) {
    if ($added >= $limit) break;
    if (!is_array($f)) continue;
    $name = (string)($f['name'] ?? '');
    $format = (string)($f['format'] ?? '');
    if ($name === '') continue;
    if (stripos($format, 'mp3') === false && stripos($name, '.mp3') === false) continue;

    $audioUrl = 'https://archive.org/download/' . rawurlencode((string)$id) . '/' . rawurlencode($name);
    if (isset($seen[$audioUrl])) continue;

    $title = (string)($f['title'] ?? ($meta['metadata']['title'] ?? $name));
    $len = (string)($f['length'] ?? '');
    $dur = parse_len($len);
    if ($dur <= 0) continue;

    $existing[] = [
      'title' => $title,
      'artist' => is_string($creator) ? $creator : 'Unknown',
      'duration_sec' => $dur,
      'year' => $yearInt,
      'genre' => $genre,
      'mood' => $mood,
      'audio_url' => $audioUrl
    ];

    $seen[$audioUrl] = true;
    $added++;
    echo "Added: {$title} ({$dur}s) - {$audioUrl}\n";
  }
}

file_put_contents($dataPath, json_encode($existing, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
echo "\nDone. Added: {$added}\nSaved to: data/tracks.json\n";
