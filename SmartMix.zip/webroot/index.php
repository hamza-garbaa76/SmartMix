<?php
declare(strict_types=1);
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

$styles = [
  'pop' => 'Pop',
  'rock' => 'Rock',
  'hip hop' => 'Rap / Hip-Hop',
  'r&b' => 'R&B',
  'soul' => 'Soul',
  'funk' => 'Funk',
  'jazz' => 'Jazz',
  'blues' => 'Blues',
  'classical' => 'Classique',
  'electronic' => 'Électronique',
  'house' => 'House',
  'techno' => 'Techno',
  'trance' => 'Trance',
  'drum and bass' => 'Drum & Bass',
  'dubstep' => 'Dubstep',
  'ambient' => 'Ambient',
  'lofi' => 'Lo-Fi',
  'indie' => 'Indie',
  'alternative' => 'Alternative',
  'metal' => 'Metal',
  'punk' => 'Punk',
  'reggae' => 'Reggae',
  'latin' => 'Latin',
  'country' => 'Country',
  'folk' => 'Folk',
  'afrobeat' => 'Afrobeat',
  'k-pop' => 'K-Pop',
];

$decades = [];
for ($y = 1900; $y <= 2020; $y += 10) $decades[] = $y;

// defaults
$defaultStyles = ['pop', 'house'];
$defaultDecades = [1990, 2000];
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>SmartMix</title>
  <style>
    :root{
      --bg0:#060811;
      --bg1:#0b1022;
      --card: rgba(255,255,255,.06);
      --stroke: rgba(255,255,255,.10);
      --text: rgba(236,242,255,.92);
      --muted: rgba(236,242,255,.62);
      --good: #1ed760;
      --bad: #ff6b6b;
      --a: #7dd3fc;
      --b: #a78bfa;
      --c: #34d399;
      --shadow: 0 24px 80px rgba(0,0,0,.55);
    }

    *{box-sizing:border-box}
    body{
      margin:0;
      font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial;
      color: var(--text);
      background: radial-gradient(1200px 900px at 20% 10%, rgba(125,211,252,.16), transparent 60%),
                  radial-gradient(1200px 900px at 80% 20%, rgba(167,139,250,.18), transparent 60%),
                  radial-gradient(1200px 900px at 50% 90%, rgba(52,211,153,.14), transparent 60%),
                  linear-gradient(180deg, var(--bg0), var(--bg1));
      min-height:100vh;
      overflow-x:hidden;
    }

    /* Animated aurora overlay */
    .aurora{
      position:fixed; inset:-40vmax;
      background:
        conic-gradient(from 180deg at 50% 50%,
          rgba(125,211,252,.08),
          rgba(167,139,250,.08),
          rgba(52,211,153,.08),
          rgba(125,211,252,.08));
      filter: blur(60px);
      animation: drift 14s ease-in-out infinite alternate;
      z-index:-1;
      opacity:.9;
    }
    @keyframes drift{
      0%{transform: translate(-2%, -2%) rotate(0deg) scale(1.0)}
      100%{transform: translate(2%, 2%) rotate(20deg) scale(1.06)}
    }

    .wrap{max-width:1200px;margin:0 auto;padding:28px 18px 70px}

    .topbar{
      display:flex;align-items:center;justify-content:space-between;gap:14px;
      position:sticky; top:0; padding:18px 0 12px; backdrop-filter: blur(10px);
    }
    .brand{
      display:flex;align-items:center;gap:12px;
    }
    .logo{
      width:44px;height:44px;border-radius:14px;
      background: radial-gradient(circle at 30% 30%, var(--a), transparent 60%),
                  radial-gradient(circle at 70% 30%, var(--b), transparent 60%),
                  radial-gradient(circle at 50% 80%, var(--c), transparent 60%),
                  rgba(255,255,255,.08);
      border:1px solid var(--stroke);
      box-shadow: 0 18px 60px rgba(0,0,0,.35);
      position:relative;
      overflow:hidden;
    }
    .logo:after{
      content:"";
      position:absolute; inset:-40%;
      background: conic-gradient(from 0deg, rgba(255,255,255,.0), rgba(255,255,255,.22), rgba(255,255,255,.0));
      animation: spin 2.8s linear infinite;
      opacity:.7;
    }
    @keyframes spin{to{transform:rotate(360deg)}}

    h1{margin:0;font-size:22px;letter-spacing:.2px}
    .subtitle{margin:2px 0 0;color:var(--muted);font-size:13px}

    .pill{
      font-size:12px;
      padding:8px 12px;
      border-radius:999px;
      border:1px solid var(--stroke);
      background: rgba(255,255,255,.05);
      display:flex;align-items:center;gap:8px;
      color: var(--muted);
    }
    .dot{
      width:8px;height:8px;border-radius:50%;
      background: linear-gradient(90deg, var(--a), var(--b), var(--c));
      box-shadow: 0 0 12px rgba(125,211,252,.35);
    }

    .grid{
      display:grid;
      grid-template-columns: 1.1fr .9fr;
      gap:16px;
    }
    @media(max-width:980px){ .grid{grid-template-columns:1fr} }

    .card{
      background: var(--card);
      border: 1px solid var(--stroke);
      border-radius: 18px;
      box-shadow: var(--shadow);
      backdrop-filter: blur(12px);
      overflow:hidden;
    }
    .cardHd{
      padding:16px 16px 12px;
      border-bottom: 1px solid rgba(255,255,255,.08);
      display:flex;align-items:center;justify-content:space-between;gap:10px;
    }
    .cardHd h2{
      margin:0;font-size:14px;letter-spacing:.35px;text-transform:uppercase;
      color: rgba(236,242,255,.72);
    }
    .cardBd{padding:16px}

    .help{color:var(--muted);font-size:13px;margin-top:8px;line-height:1.35}

    .chipGrid{
      display:grid;
      grid-template-columns: repeat(4, minmax(0,1fr));
      gap:10px;
      margin-top:10px;
    }
    @media(max-width:980px){ .chipGrid{grid-template-columns: repeat(2, minmax(0,1fr));} }

    .chip{
      border:1px solid rgba(255,255,255,.12);
      background: rgba(255,255,255,.05);
      border-radius: 14px;
      padding:10px 12px;
      display:flex; align-items:center; gap:10px;
      cursor:pointer;
      transition: transform .12s ease, background .12s ease, border-color .12s ease;
      user-select:none;
    }
    .chip:hover{transform: translateY(-1px); border-color: rgba(255,255,255,.18); background: rgba(255,255,255,.07)}
    .chip input{transform: scale(1.1)}
    .chip span{font-weight:650}
    .chip small{color: var(--muted);display:block;margin-top:2px;font-size:12px}

    .controls{
      display:grid;
      grid-template-columns: 1fr;
      gap:14px;
    }

    .label{display:flex;align-items:flex-end;justify-content:space-between;gap:10px}
    .label b{font-size:14px}
    .label .val{font-size:13px;color:var(--muted)}

    input[type=range]{width:100%}

    .actions{
      display:flex;gap:10px;flex-wrap:wrap;margin-top:4px
    }
    button, a.btn{
      border:0;
      border-radius: 14px;
      padding:12px 14px;
      font-weight:800;
      cursor:pointer;
      display:inline-flex; align-items:center; gap:10px;
      transition: transform .12s ease, filter .12s ease;
      text-decoration:none;
    }
    button:hover, a.btn:hover{transform: translateY(-1px); filter: brightness(1.03)}
    button:disabled{opacity:.55; cursor:not-allowed; transform:none; filter:none}

    .primary{
      color:#04110a;
      background: linear-gradient(90deg, var(--good), rgba(52,211,153,.95));
      box-shadow: 0 18px 50px rgba(30,215,96,.18);
    }
    .secondary{
      color: var(--text);
      background: rgba(255,255,255,.06);
      border:1px solid rgba(255,255,255,.12);
    }
    .disabledLink{
      opacity:.55;
      pointer-events:none;
    }

    .spinner{
      width:18px;height:18px;
      border:3px solid rgba(0,0,0,.25);
      border-top-color:#000;
      border-radius:50%;
      animation: spin2 .8s linear infinite;
      display:none;
    }
    @keyframes spin2{to{transform: rotate(360deg)}}

    .status{margin-top:10px;color:var(--muted);font-size:13px}
    .ok{color:rgba(142,240,169,.95)}
    .err{color:var(--bad);white-space:pre-wrap;margin-top:10px;font-size:13px}

    .kpis{display:flex;gap:10px;flex-wrap:wrap}
    .kpi{
      padding:10px 12px;
      border-radius: 14px;
      border:1px solid rgba(255,255,255,.10);
      background: rgba(255,255,255,.05);
      min-width:140px;
    }
    .kpi .t{color:var(--muted);font-size:12px}
    .kpi .v{font-size:14px;font-weight:800;margin-top:2px}

    .list{margin-top:12px}
    .track{
      border-top:1px solid rgba(255,255,255,.08);
      padding:12px 2px;
      display:grid;
      grid-template-columns: 1fr auto;
      gap:10px;
      align-items:center;
      animation: pop .18s ease both;
    }
    @keyframes pop{from{opacity:0;transform:translateY(4px)} to{opacity:1;transform:translateY(0)}}
    .meta b{display:block}
    .meta small{display:block;color:var(--muted);margin-top:2px}
    audio{width:360px;max-width:100%}

    /* Loading skeleton */
    .skeleton{
      margin-top:12px;
      border-top:1px solid rgba(255,255,255,.08);
      padding-top:12px;
      display:none;
    }
    .shimmer{
      height:12px;border-radius:999px;
      background: linear-gradient(90deg, rgba(255,255,255,.06), rgba(255,255,255,.12), rgba(255,255,255,.06));
      background-size: 200% 100%;
      animation: shimmer 1.2s ease-in-out infinite;
      margin:10px 0;
    }
    @keyframes shimmer{0%{background-position:0% 0%}100%{background-position:200% 0%}}
  </style>
</head>
<body>
<div class="aurora"></div>

<div class="wrap">
  <div class="topbar">
    <div class="brand">
      <div class="logo"></div>
      <div>
        <h1>SmartMix</h1>
        <div class="subtitle">Générateur de playlist — rendu pro, mix IA + iTunes, export CSV</div>
      </div>
    </div>
    <div class="pill"><span class="dot"></span> Live mix (IA + iTunes)</div>
  </div>

  <div class="grid">
    <!-- Config -->
    <div class="card">
      <div class="cardHd">
        <h2>Configuration</h2>
        <div class="pill" title="Conseil perf">
          <span class="dot"></span> Recommandé : ≤ 4 styles & ≤ 4 époques
        </div>
      </div>
      <div class="cardBd">
        <div class="label">
          <b>Styles</b>
          <span class="val" id="stylesCount">—</span>
        </div>
        <div class="chipGrid" id="stylesGrid">
          <?php foreach ($styles as $value => $label): ?>
            <?php $checked = in_array($value, $defaultStyles, true); ?>
            <label class="chip">
              <input type="checkbox" name="styles" value="<?= h($value) ?>" <?= $checked ? 'checked' : '' ?>>
              <span><?= h($label) ?></span>
            </label>
          <?php endforeach; ?>
        </div>

        <div style="height:12px"></div>

        <div class="label">
          <b>Époques (décennies)</b>
          <span class="val" id="decadesCount">—</span>
        </div>
        <div class="chipGrid" id="decadesGrid">
          <?php foreach ($decades as $d): ?>
            <?php $checked = in_array($d, $defaultDecades, true); ?>
            <label class="chip">
              <input type="checkbox" name="decades" value="<?= (int)$d ?>" <?= $checked ? 'checked' : '' ?>>
              <span><?= (int)$d ?>s</span>
            </label>
          <?php endforeach; ?>
        </div>

        <div style="height:12px"></div>

        <div class="controls">
          <div>
            <div class="label">
              <b>Durée</b>
              <span class="val"><span id="mVal">60</span> min</span>
            </div>
            <input id="minutes" type="range" min="10" max="180" step="5" value="60">
            <div class="help">Objectif : remplir au plus proche (≈ ± 1 min). Les styles sont alternés pour éviter les séries.</div>
          </div>

          <div class="actions">
            <button id="go" class="primary" type="button">
              <span id="btnText">Générer</span>
              <span id="spinner" class="spinner"></span>
            </button>
            <a id="download" class="btn secondary disabledLink" href="#" download="playlist.csv">Télécharger CSV</a>
          </div>

          <div id="status" class="status"></div>
          <div id="error" class="err"></div>
        </div>
      </div>
    </div>

    <!-- Résultats -->
    <div class="card">
      <div class="cardHd">
        <h2>Playlist</h2>
      </div>
      <div class="cardBd">
        <div class="kpis">
          <div class="kpi"><div class="t">Cible</div><div class="v" id="target">—</div></div>
          <div class="kpi"><div class="t">Total</div><div class="v" id="total">—</div></div>
          <div class="kpi"><div class="t">Titres</div><div class="v" id="count">—</div></div>
        </div>

        <div class="skeleton" id="skeleton">
          <div class="shimmer" style="width: 80%"></div>
          <div class="shimmer" style="width: 65%"></div>
          <div class="shimmer" style="width: 72%"></div>
          <div class="shimmer" style="width: 58%"></div>
          <div class="shimmer" style="width: 76%"></div>
        </div>

        <div class="list" id="list"></div>
      </div>
    </div>
  </div>
</div>

<script>
(() => {
  const $ = (id) => document.getElementById(id);

  const minutes = $('minutes');
  const mVal = $('mVal');

  const go = $('go');
  const btnText = $('btnText');
  const spinner = $('spinner');

  const statusEl = $('status');
  const errEl = $('error');

  const targetEl = $('target');
  const totalEl = $('total');
  const countEl = $('count');

  const listEl = $('list');
  const downloadBtn = $('download');
  const skel = $('skeleton');

  const stylesCount = $('stylesCount');
  const decadesCount = $('decadesCount');

  function fmtTime(sec){
    sec = Math.max(0, Number(sec||0));
    const h = Math.floor(sec/3600);
    const m = Math.floor((sec%3600)/60);
    const s = Math.floor(sec%60);
    return h>0 ? `${h}h ${m}m ${s}s` : `${m}m ${s}s`;
  }

  function setLoading(on){
    go.disabled = on;
    spinner.style.display = on ? 'inline-block' : 'none';
    btnText.textContent = on ? 'Génération…' : 'Générer';
    skel.style.display = on ? 'block' : 'none';
  }

  function disableDownload(){
    downloadBtn.classList.add('disabledLink');
    downloadBtn.href = '#';
  }
  function enableDownload(token){
    downloadBtn.classList.remove('disabledLink');
    downloadBtn.href = `api/download.php?token=${encodeURIComponent(token)}`;
  }

  function getChecked(name){
    return Array.from(document.querySelectorAll(`input[name="${name}"]:checked`))
      .map(el => el.value).filter(Boolean);
  }

  function updateCounts(){
    stylesCount.textContent = `${getChecked('styles').length} sélectionné(s)`;
    decadesCount.textContent = `${getChecked('decades').length} sélectionné(s)`;
  }

  document.addEventListener('change', (e) => {
    if (e.target && (e.target.name === 'styles' || e.target.name === 'decades')) updateCounts();
  });

  minutes.addEventListener('input', () => mVal.textContent = minutes.value);
  mVal.textContent = minutes.value;
  disableDownload();
  updateCounts();

  go.addEventListener('click', async () => {
    errEl.textContent = '';
    listEl.innerHTML = '';
    statusEl.textContent = 'Préparation…';
    setLoading(true);
    disableDownload();

    const styles = getChecked('styles');
    const decades = getChecked('decades');

    if(styles.length === 0){
      errEl.textContent = "Choisis au moins un style.";
      statusEl.textContent = "Échec.";
      setLoading(false);
      return;
    }
    if(decades.length === 0){
      errEl.textContent = "Choisis au moins une époque.";
      statusEl.textContent = "Échec.";
      setLoading(false);
      return;
    }

    const params = new URLSearchParams({
      styles: styles.join(','),
      decades: decades.join(','),
      minutes: minutes.value
    });

    try{
      statusEl.textContent = 'Recherche de titres (IA + iTunes)…';
      const res = await fetch(`api/generate.php?${params.toString()}`, {headers:{'Accept':'application/json'}, cache:'no-store'});
      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch { throw new Error("Réponse invalide (non JSON)."); }
      if(!res.ok || data.error) throw new Error(data.error || `HTTP ${res.status}`);

      targetEl.textContent = fmtTime(data.target_sec);
      totalEl.textContent = fmtTime(data.total_sec);
      countEl.textContent = String((data.tracks||[]).length);

      statusEl.innerHTML = `<span class="ok">OK</span> — Playlist générée.`;
      if (data.token) enableDownload(data.token);

      const tracks = data.tracks || [];
      if(tracks.length === 0){
        listEl.innerHTML = `<div class="help">Aucun titre trouvé avec ces critères. Essaie d’ajouter une autre décennie ou un style plus large.</div>`;
        return;
      }

      const frag = document.createDocumentFragment();
      tracks.forEach((t, idx) => {
        const div = document.createElement('div');
        div.className = 'track';
        const page = t.page_url ? ` <a href="${t.page_url}" target="_blank" rel="noopener">Page</a>` : '';
        div.innerHTML = `
          <div class="meta">
            <b>${idx+1}. ${t.title || '(sans titre)'}</b>
            <small>${t.artist || 'Artiste inconnu'} • ${t.year || '—'} • ${fmtTime(t.duration_sec)} • ${t.style || '—'} • ${t.source || '—'} • ${page}</small>
          </div>
          <div>${t.audio_url ? `<audio controls preload="none" src="${t.audio_url}"></audio>` : ''}</div>
        `;
        frag.appendChild(div);
      });
      listEl.appendChild(frag);

    }catch(e){
      errEl.textContent = String(e.message || e);
      statusEl.textContent = 'Échec.';
    }finally{
      setLoading(false);
    }
  });
})();
</script>
</body>
</html>
