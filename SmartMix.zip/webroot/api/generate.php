<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../lib/ia.php';
require_once __DIR__ . '/../lib/itunes.php';
require_once __DIR__ . '/../lib/playlist_store.php';

function bad(int $code, string $msg): void {
  http_response_code($code);
  echo json_encode(['error' => $msg], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

$stylesParam  = trim((string)($_GET['styles'] ?? 'pop'));
$decadesParam = trim((string)($_GET['decades'] ?? '1990'));
$minutes = (int)($_GET['minutes'] ?? 60);

if ($minutes < 10 || $minutes > 180) bad(400, 'minutes doit être entre 10 et 180.');

$target = $minutes * 60;

// Parse styles
$styles = array_values(array_filter(array_map('trim', explode(',', $stylesParam))));
$styles = array_values(array_unique($styles));
if (!$styles) bad(400, 'styles vide.');

// Parse decades
$decades = array_values(array_filter(array_map('trim', explode(',', $decadesParam))));
$decades = array_values(array_unique($decades));
if (!$decades) bad(400, 'decades vide.');

$decadesInt = [];
foreach ($decades as $d) {
  if (!preg_match('~^\d{4}$~', $d)) continue;
  $di = (int)$d;
  if ($di < 1900 || $di > 2020 || ($di % 10) !== 0) continue;
  $decadesInt[] = $di;
}
$decadesInt = array_values(array_unique($decadesInt));
if (!$decadesInt) bad(400, 'Aucune décennie valide.');

// Performance caps
$MAX_STYLES = 4;
$MAX_DECADES = 4;
if (count($styles) > $MAX_STYLES) $styles = array_slice($styles, 0, $MAX_STYLES);
if (count($decadesInt) > $MAX_DECADES) $decadesInt = array_slice($decadesInt, 0, $MAX_DECADES);

// Deadline (seconds) for “live”
$deadlineSec = 4.5;
$startTime = microtime(true);

$cacheDir = __DIR__ . '/../data/cache';
ia_ensure_dir($cacheDir);

// Pools per style
$perStyle = [];
foreach ($styles as $st) $perStyle[$st] = [];

// Helper to see if time is up
$timeLeft = function() use ($startTime, $deadlineSec): float {
  return $deadlineSec - (microtime(true) - $startTime);
};

try {
  // 1) iTunes first (fast): for each (style, decade)
  foreach ($styles as $st) {
    foreach ($decadesInt as $dec) {
      if ($timeLeft() <= 0.25) break 2;

      $yStart = $dec;
      $yEnd = $dec + 9;

      $pool = itunes_get_pool($st, $yStart, $yEnd, 40);
      foreach ($pool as $t) {
        $t['style'] = $st;
        $perStyle[$st][] = $t;
      }
    }
    shuffle($perStyle[$st]);
  }

  // 2) IA fast as complement (limited): for each (style, decade)
  foreach ($styles as $st) {
    // If we already have enough for this style, skip IA
    if (count($perStyle[$st]) >= 50) continue;

    foreach ($decadesInt as $dec) {
      $left = $timeLeft();
      if ($left <= 0.25) break 2;

      $yStart = $dec;
      $yEnd = $dec + 9;

      // Need only a few from IA
      $need = 10;
      $pool = ia_get_pool_fast($st, $yStart, $yEnd, $cacheDir, $need, min(1.2, $left));
      foreach ($pool as $t) {
        $t['style'] = $st;
        $perStyle[$st][] = $t;
      }
      shuffle($perStyle[$st]);

      if (count($perStyle[$st]) >= 60) break;
    }
  }

  // 3) Build playlist round-robin per style (coherent mixing)
  $playlist = [];
  $sum = 0;
  $tolerance = 60;

  $keys = array_values($styles);
  $n = count($keys);
  $idx = 0;
  $lastStyle = null;
  $emptyTurns = 0;
  $maxEmptyTurns = $n * 12;

  while ($sum < $target - 30 && count($playlist) < 60) {
    $st = $keys[$idx % $n];
    $idx++;

    // Avoid same style twice if possible
    if ($n > 1 && $st === $lastStyle) {
      $st = $keys[$idx % $n];
      $idx++;
    }

    if (empty($perStyle[$st])) {
      $emptyTurns++;
      if ($emptyTurns > $maxEmptyTurns) break;
      continue;
    }

    $t = array_shift($perStyle[$st]);
    $d = (int)($t['duration_sec'] ?? 0);
    if ($d <= 0) continue;

    if ($sum + $d <= $target + $tolerance) {
      $playlist[] = $t;
      $sum += $d;
      $lastStyle = $st;
      $emptyTurns = 0;
    }
  }

  $payload = [
    'generated_at' => date('c'),
    'input' => [
      'styles' => $styles,
      'decades' => $decadesInt,
      'minutes' => $minutes,
      'source' => 'mix_live',
    ],
    'target_sec' => $target,
    'total_sec' => $sum,
    'tracks' => $playlist,
  ];

  $token = pl_save(__DIR__ . '/../data/playlists', $payload);

  echo json_encode([
    'token' => $token,
    'target_sec' => $target,
    'total_sec' => $sum,
    'tracks' => $playlist,
  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

} catch (Throwable $e) {
  bad(500, 'Erreur serveur: ' . $e->getMessage());
}
