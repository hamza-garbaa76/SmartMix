<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/playlist_store.php';

$token = (string)($_GET['token'] ?? '');
$data = pl_load(__DIR__ . '/../data/playlists', $token);

if (!$data) {
  http_response_code(404);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Playlist introuvable (token invalide).";
  exit;
}

$filename = 'playlist_' . date('Ymd_His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="'.$filename.'"');

$out = fopen('php://output', 'w');

// En-têtes CSV
fputcsv($out, ['Titre', 'Artiste', 'Durée (sec)', 'Année', 'Source', 'Audio URL', 'Page URL']);

foreach (($data['tracks'] ?? []) as $t) {
  fputcsv($out, [
    (string)($t['title'] ?? ''),
    (string)($t['artist'] ?? ''),
    (int)($t['duration_sec'] ?? 0),
    (int)($t['year'] ?? 0),
    (string)($t['source'] ?? ''),
    (string)($t['audio_url'] ?? ''),
    (string)($t['page_url'] ?? ''),
  ]);
}

fclose($out);
