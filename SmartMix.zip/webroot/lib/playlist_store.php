<?php
declare(strict_types=1);

function pl_ensure_dir(string $dir): void {
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
}

function pl_save(string $dir, array $payload): string {
  pl_ensure_dir($dir);
  $token = bin2hex(random_bytes(16));
  $path = rtrim($dir, '/') . '/' . $token . '.json';
  file_put_contents($path, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  return $token;
}

function pl_load(string $dir, string $token): ?array {
  $token = strtolower(trim($token));
  if (!preg_match('~^[a-f0-9]{32}$~', $token)) return null;

  $path = rtrim($dir, '/') . '/' . $token . '.json';
  if (!is_file($path)) return null;

  $raw = file_get_contents($path);
  if ($raw === false) return null;

  $data = json_decode($raw, true);
  return is_array($data) ? $data : null;
}
