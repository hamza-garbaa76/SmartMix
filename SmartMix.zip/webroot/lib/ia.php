<?php
declare(strict_types=1);

function ia_ensure_dir(string $dir): void {
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
}

function ia_http_get_json(string $url, int $timeout = 15): ?array {
  $ctx = stream_context_create([
    'http' => [
      'method' => 'GET',
      'timeout' => $timeout,
      'header' => "User-Agent: PlaylistBuilder/1.0\r\nAccept: application/json\r\n",
    ],
  ]);

  $raw = @file_get_contents($url, false, $ctx);
  if ($raw === false) return null;

  $data = json_decode($raw, true);
  return is_array($data) ? $data : null;
}

function ia_build_query(string $styleTerm, int $yearStart, int $yearEnd): string {
  $term = str_replace('"', '', trim($styleTerm));
  return sprintf(
    '(mediatype:audio AND year:[%d TO %d] AND (subject:"%s" OR title:"%s" OR description:"%s"))',
    $yearStart, $yearEnd, $term, $term, $term
  );
}

function ia_search_items_scrape(string $query, int $count = 150): array {
  $count = max(25, min(500, $count));
  $fields = implode(',', ['identifier','title','creator','year','date','subject']);
  $url = 'https://archive.org/services/search/v1/scrape'
    . '?fields=' . rawurlencode($fields)
    . '&q=' . rawurlencode($query)
    . '&count=' . $count;

  $json = ia_http_get_json($url, 12);
  if (!$json || !isset($json['items']) || !is_array($json['items'])) return [];
  return $json['items'];
}

function ia_get_metadata(string $identifier): ?array {
  return ia_http_get_json('https://archive.org/metadata/' . rawurlencode($identifier), 12);
}

function ia_get_metadata_cached(string $identifier, string $cacheDir, int $ttlSec): ?array {
  ia_ensure_dir($cacheDir);
  $safe = preg_replace('~[^a-zA-Z0-9._-]+~', '_', $identifier);
  $path = rtrim($cacheDir, '/').'/'.$safe.'.json';

  if (is_file($path)) {
    $age = time() - (int)@filemtime($path);
    if ($age >= 0 && $age < $ttlSec) {
      $raw = @file_get_contents($path);
      if ($raw !== false) {
        $data = json_decode($raw, true);
        if (is_array($data)) return $data;
      }
    }
  }

  $data = ia_get_metadata($identifier);
  if (is_array($data)) {
    @file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  }
  return $data;
}

function ia_parse_duration_to_seconds(?string $s): int {
  if (!$s) return 0;
  $s = trim($s);

  if (preg_match('~^(\d{1,2}):(\d{2})(?::(\d{2}))?$~', $s, $m)) {
    if (!empty($m[3])) return ((int)$m[1])*3600 + ((int)$m[2])*60 + (int)$m[3];
    return ((int)$m[1])*60 + (int)$m[2];
  }
  if (ctype_digit($s)) return (int)$s;
  return 0;
}

function ia_extract_mp3_tracks_from_metadata(array $meta, string $styleTerm, int $yStart, int $yEnd): array {
  $identifier = $meta['metadata']['identifier'] ?? null;
  if (!$identifier) return [];

  $year = $meta['metadata']['year'] ?? ($meta['metadata']['date'] ?? null);
  $yearInt = null;
  if (is_string($year) && preg_match('~(\d{4})~', $year, $m)) $yearInt = (int)$m[1];
  if (is_int($year)) $yearInt = $year;
  if ($yearInt !== null && ($yearInt < $yStart || $yearInt > $yEnd)) return [];

  $creator = $meta['metadata']['creator'] ?? null;
  if (is_array($creator)) $creator = implode(', ', $creator);

  $out = [];
  $files = $meta['files'] ?? [];
  if (!is_array($files)) return [];

  foreach ($files as $f) {
    if (!is_array($f)) continue;

    $format = (string)($f['format'] ?? '');
    $name = (string)($f['name'] ?? '');
    if ($name === '') continue;

    if (stripos($format, 'mp3') === false && stripos($name, '.mp3') === false) continue;

    $title = (string)($f['title'] ?? ($meta['metadata']['title'] ?? $name));
    $length = (string)($f['length'] ?? '');
    $durationSec = ia_parse_duration_to_seconds($length);
    if ($durationSec <= 0) continue;

    $audioUrl = 'https://archive.org/download/' . rawurlencode($identifier) . '/' . rawurlencode($name);
    $pageUrl = 'https://archive.org/details/' . rawurlencode($identifier);

    $out[] = [
      'title' => $title,
      'artist' => is_string($creator) ? $creator : null,
      'year' => $yearInt,
      'duration_sec' => $durationSec,
      'audio_url' => $audioUrl,
      'page_url' => $pageUrl,
      'source' => 'ia',
    ];

    if (count($out) >= 15) break;
  }

  return $out;
}

/**
 * Version "normale" (peut être plus lente)
 */
function ia_get_pool(string $style, int $yStart, int $yEnd, string $cacheDir, int $maxPool = 200): array {
  $q = ia_build_query($style, $yStart, $yEnd);
  $items = ia_search_items_scrape($q, 120);

  $pool = [];
  foreach ($items as $it) {
    if (count($pool) >= $maxPool) break;
    $id = $it['identifier'] ?? null;
    if (!$id) continue;

    $meta = ia_get_metadata_cached((string)$id, $cacheDir, 7*24*3600);
    if (!$meta) continue;

    $tracks = ia_extract_mp3_tracks_from_metadata($meta, $style, $yStart, $yEnd);
    foreach ($tracks as $t) {
      $pool[] = $t;
      if (count($pool) >= $maxPool) break;
    }
  }

  shuffle($pool);
  return $pool;
}

/**
 * Version IA "FAST" (très peu de metadata, évite les minutes)
 */
function ia_get_pool_fast(string $style, int $yStart, int $yEnd, string $cacheDir, int $need, float $timeLeftSec): array {
  $need = max(5, min(60, $need));
  if ($timeLeftSec <= 0.2) return [];

  $q = ia_build_query($style, $yStart, $yEnd);
  $items = ia_search_items_scrape($q, 50);
  if (!$items) return [];

  $out = [];
  $t0 = microtime(true);

  // On limite très fort le nombre d'identifiers metadata
  $maxIds = 3;

  foreach ($items as $it) {
    if (count($out) >= $need) break;
    if ($maxIds-- <= 0) break;
    if ((microtime(true) - $t0) > $timeLeftSec) break;

    $id = $it['identifier'] ?? null;
    if (!$id) continue;

    $meta = ia_get_metadata_cached((string)$id, $cacheDir, 7*24*3600);
    if (!$meta) continue;

    $tracks = ia_extract_mp3_tracks_from_metadata($meta, $style, $yStart, $yEnd);
    foreach ($tracks as $t) {
      $out[] = $t;
      if (count($out) >= $need) break;
    }
  }

  shuffle($out);
  return $out;
}
