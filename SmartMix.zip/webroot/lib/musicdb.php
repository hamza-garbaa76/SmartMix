<?php
declare(strict_types=1);

function smx_read_tracks(string $path): array {
  if (!is_file($path)) return [];
  $raw = file_get_contents($path);
  if ($raw === false) return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function smx_decade_range(int $decade): array {
  return [$decade, $decade + 9];
}

function smx_normalize(string $s): string {
  return strtolower(trim($s));
}

function smx_seeded_shuffle(array &$arr, int $seed): void {
  $n = count($arr);
  $state = $seed;
  for ($i = $n - 1; $i > 0; $i--) {
    $state = (int)((1103515245 * $state + 12345) & 0x7fffffff);
    $j = $state % ($i + 1);
    $tmp = $arr[$i];
    $arr[$i] = $arr[$j];
    $arr[$j] = $tmp;
  }
}

function smx_build_playlist(array $candidates, int $targetSec, int $seed): array {
  $tolerance = 60;  // allow +60s
  $stopClose = 45;  // stop if within -45s
  $maxTracks = 60;

  smx_seeded_shuffle($candidates, $seed);

  $playlist = [];
  $sum = 0;

  foreach ($candidates as $t) {
    $d = (int)($t['duration_sec'] ?? 0);
    if ($d <= 0) continue;

    if ($sum + $d <= $targetSec + $tolerance) {
      $playlist[] = $t;
      $sum += $d;
    }
    if ($sum >= $targetSec - $stopClose) break;
    if (count($playlist) >= $maxTracks) break;
  }

  // Tiny improvement: swap last track for closer match
  $best = $playlist;
  $bestSum = $sum;
  $bestDiff = abs($targetSec - $bestSum);

  if (!empty($playlist)) {
    $last = array_pop($playlist);
    $sumWithoutLast = $sum - (int)($last['duration_sec'] ?? 0);

    foreach ($candidates as $t) {
      $d = (int)($t['duration_sec'] ?? 0);
      if ($d <= 0) continue;

      $newSum = $sumWithoutLast + $d;
      if ($newSum <= $targetSec + $tolerance) {
        $diff = abs($targetSec - $newSum);
        if ($diff < $bestDiff) {
          $bestDiff = $diff;
          $bestSum = $newSum;
          $best = array_merge($playlist, [$t]);
          if ($bestDiff <= 10) break;
        }
      }
    }
  }

  return ['tracks' => array_values($best), 'total_sec' => (int)$bestSum];
}

function smx_stats(array $tracks): array {
  $genres = [];
  $moods = [];
  $sources = [];

  foreach ($tracks as $t) {
    $g = (string)($t['genre'] ?? '');
    $m = (string)($t['mood'] ?? '');
    $s = (string)($t['source'] ?? '');
    if ($g !== '') $genres[$g] = ($genres[$g] ?? 0) + 1;
    if ($m !== '') $moods[$m] = ($moods[$m] ?? 0) + 1;
    if ($s !== '') $sources[$s] = true;
  }
  arsort($genres);
  arsort($moods);

  return [
    'major_genre' => $genres ? array_key_first($genres) : null,
    'major_mood'  => $moods ? array_key_first($moods) : null,
    'sources'     => array_values(array_keys($sources)),
  ];
}

function smx_save_playlist(string $dir, array $payload): string {
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
  $token = bin2hex(random_bytes(16));
  $path = rtrim($dir, '/') . '/' . $token . '.json';
  file_put_contents($path, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  return $token;
}

function smx_load_playlist(string $dir, string $token): ?array {
  $token = preg_replace('~[^a-f0-9]+~', '', strtolower($token));
  if ($token === '') return null;

  $path = rtrim($dir, '/') . '/' . $token . '.json';
  if (!is_file($path)) return null;

  $raw = file_get_contents($path);
  if ($raw === false) return null;

  $data = json_decode($raw, true);
  return is_array($data) ? $data : null;
}

/**
 * Local filtering for tracks.json
 */
function smx_filter_local_tracks(array $tracks, string $genre, string $mood, int $yStart, int $yEnd): array {
  $genre = smx_normalize($genre);
  $mood  = smx_normalize($mood);

  $out = [];
  foreach ($tracks as $t) {
    if (!is_array($t)) continue;

    $y = (int)($t['year'] ?? 0);
    if ($y < $yStart || $y > $yEnd) continue;

    $tg = smx_normalize((string)($t['genre'] ?? ''));
    $tm = smx_normalize((string)($t['mood'] ?? ''));

    if ($tg !== $genre) continue;
    if ($tm !== $mood) continue;

    $d = (int)($t['duration_sec'] ?? 0);
    if ($d <= 0) continue;

    $out[] = [
      'title' => $t['title'] ?? null,
      'artist' => $t['artist'] ?? null,
      'duration_sec' => $d,
      'year' => $y,
      'genre' => $genre,
      'mood' => $mood,
      'audio_url' => $t['audio_url'] ?? null,
      'page_url' => null,
      'source' => 'local',
    ];
  }
  return $out;
}
