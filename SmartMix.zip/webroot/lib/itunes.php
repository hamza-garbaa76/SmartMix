<?php
declare(strict_types=1);

function itunes_http_get_json(string $url, int $timeout = 20): ?array {
  $ctx = stream_context_create([
    'http' => [
      'method' => 'GET',
      'timeout' => $timeout,
      'header' => "User-Agent: PlaylistBuilder/1.0\r\nAccept: application/json\r\n",
    ],
  ]);

  $raw = @file_get_contents($url, false, $ctx);
  if ($raw === false) return null;

  $data = json_decode($raw, true);
  return is_array($data) ? $data : null;
}

function itunes_year_from_date(?string $iso): ?int {
  if (!$iso) return null;
  if (preg_match('~(\d{4})~', $iso, $m)) return (int)$m[1];
  return null;
}

function itunes_get_pool(string $style, int $yStart, int $yEnd, int $maxPool = 200): array {
  // Use style as search term. iTunes returns previews + duration_ms.
  $term = trim($style);
  if ($term === '') $term = 'music';

  $url = 'https://itunes.apple.com/search'
    . '?term=' . rawurlencode($term)
    . '&media=music&entity=song'
    . '&limit=' . min(200, max(25, $maxPool))
    . '&country=FR';

  $json = itunes_http_get_json($url);
  $results = $json['results'] ?? [];
  if (!is_array($results)) return [];

  $pool = [];
  foreach ($results as $r) {
    if (count($pool) >= $maxPool) break;
    if (!is_array($r)) continue;

    $year = itunes_year_from_date((string)($r['releaseDate'] ?? ''));
    if ($year === null || $year < $yStart || $year > $yEnd) continue;

    $preview = (string)($r['previewUrl'] ?? '');
    if ($preview === '') continue;

    $durMs = (int)($r['trackTimeMillis'] ?? 0);
    $dur = (int)round($durMs / 1000);
    if ($dur <= 0) continue;

    $pool[] = [
      'title' => (string)($r['trackName'] ?? '(sans titre)'),
      'artist' => (string)($r['artistName'] ?? 'Artiste inconnu'),
      'year' => $year,
      'duration_sec' => $dur,
      'audio_url' => $preview,
      'page_url' => (string)($r['trackViewUrl'] ?? ''),
      'source' => 'itunes',
    ];
  }

  shuffle($pool);
  return $pool;
}
